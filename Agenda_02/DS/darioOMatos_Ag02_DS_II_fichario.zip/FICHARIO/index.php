<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <!-- <link rel="stylesheet" href="estilo.css"> -->

    <title> ETEC-EAD - DARIO O.MATOS - TI</title>
</head>


<body>

    <div class="w3-container w3-teal">
        <h2>CADASTRO</h2>
    </div>
    <br>
    <div class="w3-container">
        <p class="w3-text-green">
            <?php
            echo "PHP Funcionando com sucesso!";
            ?>
        </p>
        <p>
            <button class="w3-btn w3-blue-grey">
                <a href="cadastro.html">Página de cadastro >></a>
            </button>
        </p>
    </div>

</body>

</html>