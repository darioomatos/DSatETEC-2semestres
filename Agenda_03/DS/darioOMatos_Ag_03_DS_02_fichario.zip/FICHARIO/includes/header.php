<header class="w3-container w3-teal" style="padding:16px">
    <h5>Madeira e Cia Ltda</h5>
</header>