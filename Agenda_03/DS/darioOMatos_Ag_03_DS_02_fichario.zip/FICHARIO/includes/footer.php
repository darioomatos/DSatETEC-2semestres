<footer class="w3-container w3-teal" style="padding:16px">
    <p>Powered by: <a href="https://www.linkedin.com/in/darioomatos/" target="_blank">Dario O.Matos</a></p>
</footer>